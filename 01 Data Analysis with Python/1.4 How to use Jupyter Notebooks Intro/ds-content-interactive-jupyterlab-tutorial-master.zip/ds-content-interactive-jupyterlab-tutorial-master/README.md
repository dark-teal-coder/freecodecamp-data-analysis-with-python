### rmotr.com
# Data Science with Python Course

This material is created for our [Data Science with Python Course](https://rmotr.com/data-science-python-course)